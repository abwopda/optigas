create
    definer = root@localhost procedure STOCKPOWERPLANT_MAJ(IN productpowerplant int, IN datedujour date, IN stockdepart float)
BEGIN
	DECLARE v_id INT;
    DECLARE v_conso FLOAT;
	DECLARE fin BOOLEAN DEFAULT FALSE;
    DECLARE curseur_stock CURSOR FOR SELECT eneo_productstock.id, eneo_productstock.conso  
    FROM eneo_productstock LEFT JOIN eneo_productpowerplant on (eneo_productstock.productpowerplant_id=eneo_productpowerplant.id) 
    
    WHERE eneo_productstock.productpowerplant_id=productpowerplant AND eneo_productstock.date>datedujour ORDER BY eneo_productstock.date ASC;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin = TRUE;
	    
    OPEN curseur_stock;
    loop_curseur: LOOP
    	FETCH curseur_stock INTO v_id,v_conso;
        IF fin THEN
        	LEAVE loop_curseur;
            
        END IF;
        
        UPDATE eneo_productstock SET stocki=stockdepart, stockth=stockdepart-v_conso, stock=stockdepart-v_conso WHERE eneo_productstock.id=v_id;
        SET stockdepart=stockdepart-v_conso;       
        
    END LOOP;
    CLOSE curseur_stock;
END;


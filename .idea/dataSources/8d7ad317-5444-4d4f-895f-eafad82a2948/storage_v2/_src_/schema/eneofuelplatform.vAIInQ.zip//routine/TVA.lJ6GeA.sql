create
    definer = root@localhost procedure TVA(IN datedujour date, IN company int, IN type int, OUT tva float)
BEGIN
	IF type = 1 THEN
	SELECT eneo_tvacompany.rate INTO tva FROM eneo_tvacompany LEFT JOIN eneo_productcompany ON (eneo_tvacompany.productcompany_id=eneo_productcompany.id)WHERE  eneo_productcompany.company_id=company AND 							 eneo_tvacompany.date<=datedujour ORDER BY eneo_tvacompany.date DESC LIMIT 1;
    ELSE
    SELECT 19.25 INTO tva;
    END IF;
END;


create
    definer = root@localhost procedure COMMANDPUPOWERPLANT(IN powerplant int)
BEGIN
	DECLARE v_cp,v_product,v_type,v_powerplant,v_company INT;
    DECLARE v_pu,v_tva,v_transport,v_douane,v_qte FLOAT;
    DECLARE v_date DATE;
    DECLARE v_week DATE;
    DECLARE v_weekyear DATE;
    DECLARE v_firstdayyear DATE;
	DECLARE fin BOOLEAN DEFAULT FALSE;
    DECLARE curseur_command CURSOR FOR SELECT eneo_commandproduct.id, eneo_commandproduct.product_id,eneo_command.typeproduct_id,eneo_command.powerplant_id,eneo_command.company_id,eneo_command.week,eneo_command.weekyear  FROM eneo_commandproduct LEFT JOIN eneo_command on (eneo_commandproduct.command_id=eneo_command.id)WHERE eneo_command.powerplant_id=powerplant;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin = TRUE;
    
    OPEN curseur_command;
    loop_curseur: LOOP
    	FETCH curseur_command INTO v_cp,v_product,v_type,v_powerplant,v_company,v_week,v_weekyear;
        IF fin THEN
        	LEAVE loop_curseur;
        END IF;
		
        SET v_firstdayyear= DATE('2016-01-01');
        SET v_date = DATE_ADD(v_firstdayyear,INTERVAL v_week WEEK);
        IF v_type=2 THEN
        	CALL PU1(v_date,v_pu);
        ELSE
        	CALL PU(v_date,v_product,v_powerplant,v_company,v_pu);
        END IF;
        CALL TVA(v_date,v_company,v_type,v_tva);
        CALL DOUANE(v_date,v_product,v_douane);
        CALL TRANSPORT(v_date,v_product,v_powerplant,v_company,v_transport);
        
        UPDATE eneo_commandproduct SET pu=v_pu, tva=v_tva, transport=v_transport,custom=v_douane WHERE eneo_commandproduct.id=v_cp;
    END LOOP;
    CLOSE curseur_command;
END;


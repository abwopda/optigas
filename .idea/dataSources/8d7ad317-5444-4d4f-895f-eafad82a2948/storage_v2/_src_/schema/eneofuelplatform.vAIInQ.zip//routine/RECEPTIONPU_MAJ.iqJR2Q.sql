create
    definer = root@localhost procedure RECEPTIONPU_MAJ()
BEGIN
	DECLARE v_rp,v_product,v_type,v_powerplant,v_company INT;
    DECLARE v_pu,v_tva,v_transport,v_douane,v_qte,v_coulage FLOAT;
    DECLARE v_date DATE;
	DECLARE fin BOOLEAN DEFAULT FALSE;
    DECLARE curseur_receipt CURSOR FOR SELECT eneo_receiptproduct.id, eneo_receiptproduct.product_id,eneo_receipt.typeproduct_id,eneo_receipt.powerplant_id,eneo_receipt.company_id,eneo_receipt.loadingdate  FROM eneo_receiptproduct LEFT JOIN eneo_receipt on (eneo_receiptproduct.receipt_id=eneo_receipt.id) WHERE eneo_receipt.powerplant_id>=5;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin = TRUE;
    
    OPEN curseur_receipt;
    loop_curseur: LOOP
    	FETCH curseur_receipt INTO v_rp,v_product,v_type,v_powerplant,v_company,v_date;
        IF fin THEN
        	LEAVE loop_curseur;
            
        END IF;
        SET v_douane = NULL;
        SET v_transport = NULL;
		IF v_type=2 THEN
        	CALL PU1(v_date,v_pu,v_product,v_company);
            CALL TVA(v_date,v_company,v_type,v_tva);
        ELSE
        	CALL PU(v_date,v_product,v_powerplant,v_company,v_pu);
            CALL TVA(v_date,v_company,v_type,v_tva);
        END IF;
        
        IF v_type =2  THEN        	
            IF v_company = 1 THEN
        		CALL TRANSPORT(v_date,v_product,v_powerplant,v_company,v_transport);
                CALL DOUANE(v_date,v_product,v_douane);
				UPDATE eneo_receiptproduct SET pu=v_pu, tva=v_tva, transport=v_transport, custom=v_douane WHERE eneo_receiptproduct.id=v_rp;                 
            END IF;

        ELSE
        	CALL Coulage(v_date,v_company,v_coulage);
			UPDATE eneo_receiptproduct SET pu=v_pu, tva=v_tva,coulage=v_coulage WHERE eneo_receiptproduct.id=v_rp;             
        END IF;
              
        
    END LOOP;
    CLOSE curseur_receipt;
END;


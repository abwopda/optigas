create
    definer = root@localhost procedure DOUANE(IN datedujour date, IN product int, OUT douane float)
BEGIN
	SELECT eneo_productcustom.rate INTO douane FROM eneo_productcustom WHERE  eneo_productcustom.product_id=product AND 							 eneo_productcustom.date<=datedujour ORDER BY eneo_productcustom.date DESC LIMIT 1;
END;


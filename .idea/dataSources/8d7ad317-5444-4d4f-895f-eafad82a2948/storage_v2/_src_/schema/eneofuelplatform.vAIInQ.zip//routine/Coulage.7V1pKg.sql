create
    definer = root@localhost procedure Coulage(IN datedujour date, IN company int, OUT coulage float)
BEGIN
	SELECT eneo_coulagecompany.rate INTO coulage FROM eneo_coulagecompany WHERE  eneo_coulagecompany.company_id=company AND 							 eneo_coulagecompany.date<=datedujour ORDER BY eneo_coulagecompany.date DESC LIMIT 1;
END;


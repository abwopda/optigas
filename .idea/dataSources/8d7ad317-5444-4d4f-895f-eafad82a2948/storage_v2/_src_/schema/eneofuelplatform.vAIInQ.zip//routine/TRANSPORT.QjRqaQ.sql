create
    definer = root@localhost procedure TRANSPORT(IN datedujour date, IN product int, IN powerplant int, IN company int,
                                                 OUT transport float)
BEGIN
	SELECT eneo_productcompanytransportpowerplant.rate INTO transport FROM ((eneo_productcompanytransportpowerplant LEFT JOIN eneo_productcompanytransport ON (eneo_productcompanytransportpowerplant.productcompanytransport_id = eneo_productcompanytransport.id)) LEFT JOIN eneo_productcompany ON (eneo_productcompanytransport.productcompany_id = eneo_productcompany.id)) LEFT JOIN eneo_productpowerplant ON (eneo_productcompanytransportpowerplant.productpowerplant_id=eneo_productpowerplant.id) WHERE eneo_productpowerplant.powerplant_id=powerplant AND eneo_productcompany.company_id=company AND eneo_productcompany.product_id=product AND eneo_productcompanytransport.date<=datedujour ORDER BY eneo_productcompanytransport.date DESC LIMIT 1;
END;


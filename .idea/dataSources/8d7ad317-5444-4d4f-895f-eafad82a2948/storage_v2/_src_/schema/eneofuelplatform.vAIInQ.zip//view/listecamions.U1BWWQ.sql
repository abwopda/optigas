create definer = root@localhost view listecamions as
select `eneofuelplatform`.`eneo_powerplant`.`name`   AS `powerplant`,
       `eneofuelplatform`.`eneo_company`.`alias`     AS `company`,
       `eneofuelplatform`.`eneo_receipt`.`vehicle`   AS `vehicule`,
       count(`eneofuelplatform`.`eneo_receipt`.`id`) AS `Nombre`
from ((`eneofuelplatform`.`eneo_receipt` left join `eneofuelplatform`.`eneo_company` on ((
        `eneofuelplatform`.`eneo_receipt`.`company_id` = `eneofuelplatform`.`eneo_company`.`id`)))
         left join `eneofuelplatform`.`eneo_powerplant`
                   on ((`eneofuelplatform`.`eneo_receipt`.`powerplant_id` = `eneofuelplatform`.`eneo_powerplant`.`id`)))
where (`eneofuelplatform`.`eneo_receipt`.`date` between '2016-01-01' and '2016-06-30')
group by `eneofuelplatform`.`eneo_powerplant`.`name`, `eneofuelplatform`.`eneo_company`.`alias`,
         `eneofuelplatform`.`eneo_receipt`.`vehicle`;


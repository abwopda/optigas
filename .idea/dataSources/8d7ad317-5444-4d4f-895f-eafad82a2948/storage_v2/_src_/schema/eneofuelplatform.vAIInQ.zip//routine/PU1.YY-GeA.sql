create
    definer = root@localhost procedure PU1(IN datedujour date, OUT pu float, IN product int, IN company int)
BEGIN
	SELECT eneo_productcompanyprice.price INTO pu FROM eneo_productcompanyprice LEFT JOIN eneo_productcompany ON (eneo_productcompanyprice.productcompany_id = eneo_productcompany.id) WHERE eneo_productcompanyprice.date<=datedujour AND eneo_productcompany.company_id=company AND 							eneo_productcompany.product_id=product ORDER BY eneo_productcompanyprice.date DESC LIMIT 1;
END;


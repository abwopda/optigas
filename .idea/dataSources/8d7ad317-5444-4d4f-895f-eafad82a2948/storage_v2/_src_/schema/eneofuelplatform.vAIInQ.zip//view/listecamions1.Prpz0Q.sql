create view listecamions1 as
select `eneofuelplatform`.`eneo_company`.`alias`     AS `company`,
       `eneofuelplatform`.`eneo_receipt`.`vehicle`   AS `vehicule`,
       count(`eneofuelplatform`.`eneo_receipt`.`id`) AS `Nombre`
from (`eneofuelplatform`.`eneo_receipt`
         left join `eneofuelplatform`.`eneo_company`
                   on ((`eneofuelplatform`.`eneo_receipt`.`company_id` = `eneofuelplatform`.`eneo_company`.`id`)))
where (`eneofuelplatform`.`eneo_receipt`.`date` between '2016-01-01' and '2016-06-30')
group by `eneofuelplatform`.`eneo_company`.`alias`, `eneofuelplatform`.`eneo_receipt`.`vehicle`;


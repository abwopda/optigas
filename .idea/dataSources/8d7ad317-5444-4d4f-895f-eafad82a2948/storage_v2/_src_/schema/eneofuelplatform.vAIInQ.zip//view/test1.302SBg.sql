create view test1 as
select `eneofuelplatform`.`eneo_productstock`.`stocki` AS `stocki`,
       `eneofuelplatform`.`eneo_productstock`.`energy` AS `energy`,
       `eneofuelplatform`.`eneo_productstock`.`en`     AS `en`,
       `eneofuelplatform`.`eneo_productstock`.`conso`  AS `conso`,
       `eneofuelplatform`.`eneo_productstock`.`stock`  AS `stock`
from `eneofuelplatform`.`eneo_productstock`
where ((`eneofuelplatform`.`eneo_productstock`.`productpowerplant_id` = 18) and
       (`eneofuelplatform`.`eneo_productstock`.`date` >= '2017-09-26'))
order by `eneofuelplatform`.`eneo_productstock`.`date`;


create
    definer = root@localhost procedure PU(IN datedujour date, IN product int, IN powerplant int, IN company int,
                                          OUT pu float)
BEGIN
	SELECT eneo_productcompanypricepowerplant.price INTO pu FROM ((eneo_productcompanypricepowerplant LEFT JOIN eneo_productcompanyprice ON (eneo_productcompanypricepowerplant.productcompanyprice_id = eneo_productcompanyprice.id)) LEFT JOIN eneo_productcompany ON (eneo_productcompanyprice.productcompany_id = eneo_productcompany.id)) LEFT JOIN eneo_productpowerplant ON (eneo_productcompanypricepowerplant.productpowerplant_id=eneo_productpowerplant.id) WHERE eneo_productpowerplant.powerplant_id=powerplant AND eneo_productcompany.company_id=company AND 							eneo_productcompany.product_id=product AND eneo_productcompanyprice.date<=datedujour ORDER BY eneo_productcompanyprice.date DESC LIMIT 1;
END;

